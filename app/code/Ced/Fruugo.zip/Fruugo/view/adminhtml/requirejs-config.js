
var config = {
    map: {
        "*": {
            "mage/adminhtml/grid": "Ced_Fruugo/js/grid",
        }
    }
}